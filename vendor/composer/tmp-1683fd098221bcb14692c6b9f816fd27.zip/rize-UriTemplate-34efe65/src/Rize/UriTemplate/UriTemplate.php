<?php

namespace Rize\UriTemplate;

use Rize\UriTemplate as Template;

/**
 * Future compatibility
 */
class UriTemplate extends Template
{
}
